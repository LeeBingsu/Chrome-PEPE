# SingleFile

## Contributors

- Azerbaijani translation done by Haciagha_Sadikhov (https://github.com/Hajiagha-Sadikhov)
- Chinese translation done by yfdyh000 (https://github.com/yfdyh000), Liu8Can
  (https://github.com/Liu8Can), KrasnayaPloshchad 
  (https://github.com/KrasnayaPloshchad), frostblazergit
  (https://github.com/frostblazergit), dnknn (https://github.com/dnknn),
  lqzhgood (https://github.com/lqzhgood)
- Traditional Chinese translation done by frostblazergit
  (https://github.com/frostblazergit), lqzhgood (https://github.com/lqzhgood)
- Dutch translation done by jooleer (https://github.com/jooleer)
- German translation done by womotroll (https://github.com/womotroll), bannmann
  (https://github.com/bannmann)
- Italian translation done by Fastbyte01 (https://github.com/Fastbyte01)
- Japanese translation done by Shitennouji（四天王寺)
  (https://github.com/Shitennouji)
- Polish translation done by xesarni (https://github.com/xesarni)
- Portuguese translation done by Blackspirits (https://github.com/Blackspirits)
- Portuguese-Brazilian translation done by @mezysinc, Blackspirits
  (https://github.com/Blackspirits)
- Russian translation done by rstp14, kramola-RU
  (https://github.com/kramola-RU), solokot (https://github.com/solokot),
  TotalCaesar659 (https://github.com/TotalCaesar659)
- Spanish translation done by strel (https://github.com/strel)
- Swedish translation done by NickWick13 (https://github.com/NickWick13)
- Turkish translation done by hbaklan943 (https://github.com/hbaklan943)
- Ukrainian translation done by perdolka (https://github.com/perdolka)
