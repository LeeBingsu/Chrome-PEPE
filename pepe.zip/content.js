﻿setInterval(()=>{
    let imgs = document.querySelectorAll("img");
    imgs.forEach((a,i)=>{
        a.src = 'https://raw.githubusercontent.com/LeeBingsu/Chrome-PEPE/refs/heads/main/IMG_1419.webp'
    })
},100)
