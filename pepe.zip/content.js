setInterval(()=>{
    let imgs = document.querySelectorAll("img");
    imgs.forEach((a,i)=>{
        a.src = 'https://i.namu.wiki/i/wn9cqaS6OmCuLmhrJH7z_4H4AOJRolAt-LUJqHvM3zjnbQ9RhEfc2-lETU-TAx-5iJeGPIL6daB6S9aQZ9ZrgEaQ80Pl1KqbGCc-gxe2ZtYqC9JuE2wbovWckalXpZYa5mq0MoFRT8wFFot1UndRww.webp'
    })
},100)