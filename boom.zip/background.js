// Function to schedule the next alarm with a random interval between 30 and 120 minutes (30분 ~ 2시간)
function scheduleNextAlarm() {
  const min = 1;
  const max = 60;

  const randomMinutes = Math.random() * (max - min) + min;
  console.log(`[Work Protector] Next alarm scheduled in ${randomMinutes.toFixed(2)} minutes.`);
  chrome.alarms.create("work_protector_alarm", {
    delayInMinutes: randomMinutes
  });
}

// Initialize settings on install or startup
chrome.runtime.onInstalled.addListener(() => {
  scheduleNextAlarm();
});

chrome.runtime.onStartup.addListener(() => {
  scheduleNextAlarm();
});

// Alarm trigger listener
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "work_protector_alarm") {
    // Send showModal action to the active tab
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, { action: "showModal" }, (response) => {
          // Ignore errors where content script is not loaded yet or on chrome:// pages
          if (chrome.runtime.lastError) {
            console.log("[Work Protector] Active tab is not eligible for modal injection.");
          }
        });
      }
      // Set the next alarm
      scheduleNextAlarm();
    });
  }
});

let activeModalTabId = null;

// Message listener for popup actions, tab closing, and modal states
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "closeAllTabs") {
    // Query all tabs across all windows and close them
    chrome.tabs.query({}, (tabs) => {
      const tabIds = tabs.map(tab => tab.id);
      chrome.tabs.remove(tabIds, () => {
        if (chrome.runtime.lastError) {
          console.error("[Work Protector] Error closing tabs:", chrome.runtime.lastError);
        }
      });
    });
  } else if (message.action === "triggerModal") {
    // Find active tab and trigger the modal immediately for testing (still useful for developers)
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, { action: "showModal" }, (response) => {
          if (chrome.runtime.lastError) {
            sendResponse({ success: false, error: "이 페이지에서는 테스트할 수 없습니다. 일반 웹사이트에서 시도해 주세요." });
          } else {
            sendResponse({ success: true });
          }
        });
      } else {
        sendResponse({ success: false, error: "활성화된 탭을 찾을 수 없습니다." });
      }
    });
    return true; // Keep message channel open for async response
  } else if (message.action === "modalOpened" && sender.tab) {
    activeModalTabId = sender.tab.id;
  } else if (message.action === "modalClosed") {
    activeModalTabId = null;
  }
});

// Force focus back to the modal tab if the user tries to switch tabs
chrome.tabs.onActivated.addListener((activeInfo) => {
  if (activeModalTabId !== null && activeInfo.tabId !== activeModalTabId) {
    chrome.tabs.update(activeModalTabId, { active: true }, () => {
      if (chrome.runtime.lastError) {
        // Tab might have been closed/removed, clear the active modal tracker
        activeModalTabId = null;
      }
    });
  }
});

// Clear active modal tracker if the modal tab is closed by the user
chrome.tabs.onRemoved.addListener((tabId, removeInfo) => {
  if (tabId === activeModalTabId) {
    activeModalTabId = null;
  }
});
