// Prevent multiple dialog instances on the same page
let modalContainer = null;
let currentStep = 0;
let isShuffling = false;
let isActionPending = false;
let isRevealed = true;

// Stored slots for card button positions
let slotA = null;
let slotB = null;

// Buttons track variables for role assignment
let yesButtonElement = null;
let noButtonElement = null;

// Prevent reload / navigation
const preventUnload = (e) => {
  e.preventDefault();
  e.returnValue = "하시던 지랄을 계속 하셔야 합니다!";
  return e.returnValue;
};

// Prevent hotkeys (F5, Ctrl+R, Alt+Arrows)
const preventKeys = (e) => {
  const isF5 = e.key === "F5" || e.keyCode === 116;
  const isR = (e.ctrlKey || e.metaKey) && (e.key === "r" || e.key === "R" || e.keyCode === 82);
  const isAltNav = e.altKey && (e.key === "ArrowLeft" || e.key === "ArrowRight");

  if (isF5 || isR || isAltNav) {
    e.preventDefault();
    e.stopPropagation();
  }
};

const prompts = [
  "하시던 지랄을 계속 하시겠습니가?", // Step 0
  "다시한번 생각해보세요",             // Step 1
  "정말요?",                         // Step 2
  "ㄹㅇ??",                         // Step 3
  "눈 깜빡하지 마세요. 위치가 바뀔 수 있습니다! 👀", // Step 4
  "어, 방금 버튼 위치 바뀐 것 같은데요? 🧐", // Step 5
  "마우스 클릭하기 전에 글자를 잘 확인하세요!", // Step 6
  "아직은 제자리에서 섞이기만 합니다. 안심하지 마세요.", // Step 7
  "슬슬 머리가 아파오시나요? 아니오를 누르면 편해집니다.", // Step 8
  "다음 단계부터는 버튼이 가만히 있지 않을 겁니다! 🚨", // Step 9
  "버튼 이동 시작! 마우스 한 번 올려보시죠? 🏃‍♂️", // Step 10
  "화면 전체가 버튼의 무대입니다! 잘 쫓아가보세요.", // Step 11
  "아니오 버튼도 가만히 있지 않습니다! 🤭", // Step 12
  "조준 실력이 필요할 때입니다.", // Step 13
  "포기하면 편합니다. 단 한 번의 '아니오' 클릭이면 끝납니다.", // Step 14
  "컴퓨터: '주인님... 그만 도망 다니고 쉬어요...'", // Step 15
  "잠시 후 17단계부터는 대망의 '야바위'가 시작됩니다!", // Step 16
  "야바위 1단계! 눈 크게 뜨고 '예' 버튼을 추적하세요! 🔍", // Step 17
  "야바위 2단계! 속도가 조금 더 빨라집니다. ⚡", // Step 18
  "야바위 3단계! 진짜 '예' 버튼은 어디에 숨었을까요?", // Step 19
  "야바위 4단계! 정신이 혼미해지는 셔플!", // Step 20
  "야바위 5단계! 당신의 동체시력을 시험해봅니다.", // Step 21
  "마지막 관문 도달 직전! 진짜 계속 가실 건가요?", // Step 22
  "축하합니다! 고난을 이겨내셨습니다. 마지막 최후의 선택입니다." // Step 23
];

function getPrompt(step) {
  if (step < prompts.length) {
    return prompts[step];
  } else {
    return "마지막 선택입니다. 이제 하나만 골라주세요. 😊";
  }
}

// Function to send message to close all tabs
function closeAllTabs() {
  // Remove reload & keyblock handlers so browser can close the tabs programmatically
  window.removeEventListener("beforeunload", preventUnload);
  window.removeEventListener("keydown", preventKeys, true);

  chrome.runtime.sendMessage({ action: "modalClosed" });
  chrome.runtime.sendMessage({ action: "closeAllTabs" });

  if (modalContainer) {
    modalContainer.remove();
    modalContainer = null;
  }
}

// Function to detach buttons from document flow and fix them to the viewport
function detachButtons() {
  const activeRoot = modalContainer ? modalContainer.shadowRoot : null;
  if (!activeRoot) return;

  const overlay = activeRoot.querySelector(".overlay");
  const btnYes = activeRoot.getElementById("btn-yes");
  const btnNo = activeRoot.getElementById("btn-no");

  if (!overlay || !btnYes || !btnNo) return;
  if (btnYes.style.position === "fixed") return;

  const yesRect = btnYes.getBoundingClientRect();
  const noRect = btnNo.getBoundingClientRect();

  // Store the initial slots inside the card before changing position to fixed
  if (!slotA || !slotB) {
    slotA = { left: yesRect.left, top: yesRect.top };
    slotB = { left: noRect.left, top: noRect.top };
  }

  // Append directly to the overlay to bypass the card's CSS transform containing block restriction
  overlay.appendChild(btnYes);
  overlay.appendChild(btnNo);

  btnYes.style.position = "fixed";
  btnYes.style.width = `${yesRect.width}px`;
  btnYes.style.height = `${yesRect.height}px`;
  btnYes.style.left = `${yesRect.left}px`;
  btnYes.style.top = `${yesRect.top}px`;
  btnYes.style.margin = "0";
  btnYes.style.zIndex = "2147483647";

  btnNo.style.position = "fixed";
  btnNo.style.width = `${noRect.width}px`;
  btnNo.style.height = `${noRect.height}px`;
  btnNo.style.left = `${noRect.left}px`;
  btnNo.style.top = `${noRect.top}px`;
  btnNo.style.margin = "0";
  btnNo.style.zIndex = "2147483647";
}

// Function to make button jump to a random spot on the screen
function jumpButton(btn) {
  if (isShuffling) return;

  // Only dodge during clicks 11 to 17 (steps 10 to 16)
  if (currentStep < 10 || currentStep > 16) return;

  if (Math.random() < 0.90) {
    btn.style.transition = "transform 0.15s ease"; // Snap instantly without sliding

    const btnRect = btn.getBoundingClientRect();
    const maxX = window.innerWidth - btnRect.width - 40;
    const maxY = window.innerHeight - btnRect.height - 40;

    const randomX = Math.max(20, Math.floor(Math.random() * maxX));
    const randomY = Math.max(20, Math.floor(Math.random() * maxY));

    btn.style.left = `${randomX}px`;
    btn.style.top = `${randomY}px`;

    btn.style.transform = "scale(0.8)";
    setTimeout(() => {
      btn.style.transform = "scale(1)";
    }, 150);
  }
}

// Function to inject and show the modal
function showModal() {
  if (modalContainer) return; // Already showing

  currentStep = 0;
  isShuffling = false;
  isActionPending = false;
  isRevealed = true;
  slotA = null;
  slotB = null;

  // Notify background script that the modal has opened (to lock tab focus)
  chrome.runtime.sendMessage({ action: "modalOpened" });

  // Register reload & keyblock handlers
  window.addEventListener("beforeunload", preventUnload);
  window.addEventListener("keydown", preventKeys, true);

  // Create a container element
  modalContainer = document.createElement("div");
  modalContainer.id = "work-protector-extension-root";
  modalContainer.style.position = "fixed";
  modalContainer.style.top = "0";
  modalContainer.style.left = "0";
  modalContainer.style.width = "100vw";
  modalContainer.style.height = "100vh";
  modalContainer.style.zIndex = "2147483647"; // Max z-index
  document.body.appendChild(modalContainer);

  const shadowRoot = modalContainer.attachShadow({ mode: "open" });

  const style = document.createElement("style");
  style.textContent = `
    .overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.40);
      display: flex;
      align-items: center;
      justify-content: center;
      opacity: 0;
      animation: fadeIn 0.2s ease forwards;
    }

    .card {
      background: #ffffff;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      padding: 28px;
      width: 400px;
      box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
      text-align: center;
      transform: scale(0.95);
      animation: cardIn 0.2s ease forwards;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans KR", sans-serif;
      box-sizing: border-box;
      color: #0f172a;
    }

    .icon-wrapper {
      width: 48px;
      height: 48px;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 16px auto;
    }

    .icon-svg {
      width: 40px;
      height: 40px;
      color: #4f46e5;
    }

    .title {
      font-size: 13px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 1px;
      color: #64748b;
      margin: 0 0 12px 0;
    }

    .message {
      font-size: 18px;
      font-weight: 500;
      line-height: 1.6;
      color: #0f172a;
      margin: 0 0 28px 0;
      word-break: keep-all;
      min-height: 56px;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .btn-group {
      display: flex;
      gap: 12px;
      justify-content: center;
      position: relative;
      height: 40px;
    }

    .btn {
      flex: 1;
      height: 40px;
      border-radius: 6px;
      font-size: 15px;
      font-weight: 600;
      cursor: pointer;
      border: none;
      outline: none;
      user-select: none;
      box-sizing: border-box;
    }

    .btn-yes {
      background: #4f46e5;
      color: #ffffff;
      order: 1;
      position: relative;
      transition: transform 0.15s ease;
    }

    .btn-yes:hover {
      background: #3730a3;
    }

    .btn-no {
      background: #f1f5f9;
      border: 1px solid #cbd5e1;
      color: #475569;
      order: 2;
      transition: background 0.15s, color 0.15s, border-color 0.15s;
    }

    .btn-no:hover {
      background: #ef4444;
      border-color: #ef4444;
      color: #ffffff;
    }

    @keyframes fadeIn {
      to { opacity: 1; }
    }

    @keyframes cardIn {
      to { transform: scale(1); }
    }
    
    .wiggle {
      animation: wiggle 0.3s ease;
    }
    
    @keyframes wiggle {
      0%, 100% { transform: translateX(0); }
      25% { transform: translateX(-4px); }
      75% { transform: translateX(4px); }
    }
  `;
  shadowRoot.appendChild(style);

  // Create UI Structure
  const overlay = document.createElement("div");
  overlay.className = "overlay";

  const card = document.createElement("div");
  card.className = "card";

  const iconWrapper = document.createElement("div");
  iconWrapper.className = "icon-wrapper";
  iconWrapper.innerHTML = `
    <svg class="icon-svg" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
    </svg>
  `;

  const title = document.createElement("h2");
  title.className = "title";
  title.textContent = "쉬어가자 ㅇㅈ?";

  const message = document.createElement("p");
  message.className = "message";
  message.textContent = prompts[0];

  const btnGroup = document.createElement("div");
  btnGroup.className = "btn-group";

  const btnYes = document.createElement("button");
  btnYes.className = "btn btn-yes";
  btnYes.id = "btn-yes";
  btnYes.textContent = "예";

  const btnNo = document.createElement("button");
  btnNo.className = "btn btn-no";
  btnNo.id = "btn-no";
  btnNo.textContent = "아니오";

  btnGroup.appendChild(btnYes);
  btnGroup.appendChild(btnNo);

  card.appendChild(iconWrapper);
  card.appendChild(title);
  card.appendChild(message);
  card.appendChild(btnGroup);
  overlay.appendChild(card);
  shadowRoot.appendChild(overlay);

  // Set initial roles
  yesButtonElement = btnYes;
  noButtonElement = btnNo;

  // Block clicks from passing to the background page
  overlay.addEventListener("click", (e) => e.stopPropagation());
  overlay.addEventListener("mousedown", (e) => e.stopPropagation());
  overlay.addEventListener("mouseup", (e) => e.stopPropagation());

  // Function to run the cup/shell game shuffle with acceleration from initial positions
  function runShellGame(onComplete) {
    isShuffling = true;
    detachButtons();

    // Randomly assign initial role layouts for the pre-shuffle reveal
    if (Math.random() < 0.5) {
      yesButtonElement = btnYes;
      noButtonElement = btnNo;
    } else {
      yesButtonElement = btnNo;
      noButtonElement = btnYes;
    }

    // Set correct texts and styles for starting state reveal
    yesButtonElement.textContent = "예";
    yesButtonElement.style.background = "#4f46e5";
    yesButtonElement.style.color = "#ffffff";
    yesButtonElement.style.border = "none";

    noButtonElement.textContent = "아니오";
    noButtonElement.style.background = "#f1f5f9";
    noButtonElement.style.color = "#475569";
    noButtonElement.style.border = "1px solid #cbd5e1";

    // Position buttons back to their card slots initially
    let pos1 = { ...slotA };
    let pos2 = { ...slotB };

    btnYes.style.transition = "top 0.2s ease, left 0.2s ease";
    btnNo.style.transition = "top 0.2s ease, left 0.2s ease";

    btnYes.style.left = `${pos1.left}px`;
    btnYes.style.top = `${pos1.top}px`;
    btnNo.style.left = `${pos2.left}px`;
    btnNo.style.top = `${pos2.top}px`;

    message.textContent = "👀 시작 위치를 확인하세요!";

    // Wait exactly 1 second before hiding roles and starting shuffle
    setTimeout(() => {
      if (!modalContainer) return; // Guard if destroyed

      // Turn buttons into "?" and gray
      btnYes.textContent = "?";
      btnNo.textContent = "?";
      btnYes.style.background = "#64748b";
      btnYes.style.color = "#ffffff";
      btnYes.style.border = "none";
      btnNo.style.background = "#64748b";
      btnNo.style.color = "#ffffff";
      btnNo.style.border = "none";

      message.textContent = "...";

      let count = 0;
      const maxShuffles = 14; // Shuffle 14 times
      let currentDelay = 850; // Start at 850ms

      function swapStep() {
        if (!modalContainer) return;

        // Swap targets
        const temp = pos1;
        pos1 = pos2;
        pos2 = temp;

        // Apply transition duration relative to current delay
        const transitionSec = `${currentDelay / 1000}s`;
        btnYes.style.transition = `top ${transitionSec} ease-in-out, left ${transitionSec} ease-in-out`;
        btnNo.style.transition = `top ${transitionSec} ease-in-out, left ${transitionSec} ease-in-out`;

        // Swapping with vertical circular curve
        const direction = count % 2 === 0 ? 1 : -1;
        const verticalOffset = 30 * direction;

        btnYes.style.left = `${pos1.left}px`;
        btnYes.style.top = `${pos1.top + verticalOffset}px`;
        btnNo.style.left = `${pos2.left}px`;
        btnNo.style.top = `${pos2.top - verticalOffset}px`;

        // Reset to flat baseline halfway through
        setTimeout(() => {
          if (!modalContainer) return;
          btnYes.style.top = `${pos1.top}px`;
          btnNo.style.top = `${pos2.top}px`;
        }, currentDelay / 2);

        count++;
        if (count < maxShuffles) {
          // Accelerate gradually
          currentDelay = Math.max(350, currentDelay - 35);
          setTimeout(swapStep, currentDelay);
        } else {
          // Shuffling complete
          setTimeout(() => {
            isShuffling = false;
            btnYes.style.left = `${pos1.left}px`;
            btnYes.style.top = `${pos1.top}px`;
            btnNo.style.left = `${pos2.left}px`;
            btnNo.style.top = `${pos2.top}px`;
            if (onComplete) onComplete();
          }, currentDelay);
        }
      }

      // Start the shuffle loop
      setTimeout(swapStep, currentDelay);
    }, 1000);
  }

  // Instantly reveal the true roles of the buttons on click
  function revealRoles() {
    isRevealed = true;

    btnYes.style.transition = "transform 0.15s ease, background 0.2s ease";
    btnNo.style.transition = "transform 0.15s ease, background 0.2s ease";

    if (currentStep >= 23) {
      btnYes.textContent = "아니오";
      btnYes.style.background = "#f1f5f9";
      btnYes.style.color = "#475569";
      btnYes.style.border = "1px solid #cbd5e1";

      btnNo.textContent = "아니오";
      btnNo.style.background = "#f1f5f9";
      btnNo.style.color = "#475569";
      btnNo.style.border = "1px solid #cbd5e1";
    } else {
      yesButtonElement.textContent = "예";
      yesButtonElement.style.background = "#4f46e5";
      yesButtonElement.style.color = "#ffffff";
      yesButtonElement.style.border = "none";

      noButtonElement.textContent = "아니오";
      noButtonElement.style.background = "#f1f5f9";
      noButtonElement.style.color = "#475569";
      noButtonElement.style.border = "1px solid #cbd5e1";
    }
  }

  // Reveal standard Yes / No buttons (non-shell game mode)
  function revealButtons() {
    if (Math.random() < 0.5) {
      yesButtonElement = btnYes;
      noButtonElement = btnNo;
    } else {
      yesButtonElement = btnNo;
      noButtonElement = btnYes;
    }

    yesButtonElement.textContent = "예";
    yesButtonElement.style.background = "#4f46e5";
    yesButtonElement.style.color = "#ffffff";
    yesButtonElement.style.border = "none";
    yesButtonElement.style.transition = "transform 0.15s ease, background 0.2s ease";

    noButtonElement.textContent = "아니오";
    noButtonElement.style.background = "#f1f5f9";
    noButtonElement.style.color = "#475569";
    noButtonElement.style.border = "1px solid #cbd5e1";
    noButtonElement.style.transition = "transform 0.15s ease, background 0.2s ease";

    message.textContent = getPrompt(currentStep);
  }

  // Function to advance steps
  const nextStep = () => {
    currentStep++;

    // Apply a wiggle animation to the card when step advances
    card.classList.remove("wiggle");
    void card.offsetWidth; // Trigger reflow
    card.classList.add("wiggle");

    // Click 11 to 17 correspond to steps 10 to 16
    if (currentStep >= 10) {
      detachButtons();
    }

    // Stage 1: Clicks 1-10 (Steps 0-9) -> Stay inside card, swap positions
    if (currentStep < 10) {
      if (currentStep >= 3) {
        if (Math.random() < 0.5) {
          btnYes.style.order = "2";
          btnNo.style.order = "1";
        } else {
          btnYes.style.order = "1";
          btnNo.style.order = "2";
        }
      }
      message.textContent = getPrompt(currentStep);
    }
    // Stage 2: Clicks 11-17 (Steps 10-16) -> Dodge screen-wide, no shuffling
    else if (currentStep >= 10 && currentStep <= 16) {
      revealButtons();
    }
    // Stage 3: Clicks 18-22 (Steps 17-22) -> Shell game (야바위) shuffling, no dodging
    else if (currentStep >= 17 && currentStep < 23) {
      isRevealed = false;
      runShellGame(() => {
        message.textContent = "물음표 버튼 중 진짜 '예' 버튼을 골라보세요! 🤔";
      });
    }
    // Stage 4: Click 23+ (Step 23+) -> Final Shell Game shuffle, reveal both as "아니오"
    else if (currentStep >= 23) {
      isRevealed = false;
      runShellGame(() => {
        yesButtonElement = null;
        noButtonElement = null;
        message.textContent = "대망의 마지막 선택입니다! 하나를 골라보세요. 😊";
      });
    }
  };

  // Main click handler for button clicks
  const handleButtonClick = (clickedBtn) => {
    if (isShuffling || isActionPending) return;

    // Shell game interactive click handler (clicks 18 onwards / steps 17+)
    if (currentStep >= 17 && !isRevealed) {
      isActionPending = true;

      if (currentStep >= 23) {
        revealRoles();
        message.textContent = "ㅋ";
        setTimeout(() => {
          isActionPending = false;
          closeAllTabs();
        }, 2000);
        return;
      }

      revealRoles();
      if (clickedBtn === yesButtonElement) {
        message.textContent = "잘하셨어요! 다음 단계로 넘어갑니다ㅋ";
        setTimeout(() => {
          isActionPending = false;
          nextStep();
        }, 1000);
      } else {
        message.textContent = "저런..";
        setTimeout(() => {
          isActionPending = false;
          closeAllTabs();
        }, 2000);
      }
      return;
    }

    // Normal click handler (Steps 0 to 16)
    if (currentStep >= 23) {
      message.textContent = "저런..";
      isActionPending = true;
      setTimeout(() => {
        isActionPending = false;
        closeAllTabs();
      }, 2000);
      return;
    }

    if (clickedBtn === yesButtonElement) {
      nextStep();
    } else {
      message.textContent = "저런..";
      isActionPending = true;
      setTimeout(() => {
        isActionPending = false;
        closeAllTabs();
      }, 2000);
    }
  };

  btnYes.addEventListener("click", (e) => {
    e.stopPropagation();
    handleButtonClick(btnYes);
  });

  btnNo.addEventListener("click", (e) => {
    e.stopPropagation();
    handleButtonClick(btnNo);
  });

  // Dodging / runaway triggers on hover
  btnYes.addEventListener("mouseenter", () => {
    if (currentStep >= 10 && currentStep <= 16 && !isShuffling) {
      jumpButton(btnYes);
    }
  });

  btnNo.addEventListener("mouseenter", () => {
    if (currentStep >= 10 && currentStep <= 16 && !isShuffling) {
      jumpButton(btnNo);
    }
  });
}

// Listen for messages from background script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "showModal") {
    showModal();
    sendResponse({ success: true });
  }
});
